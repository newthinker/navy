/*     */ package cn.com.hd.dto.priv;
/*     */ 
/*     */ import cn.com.hd.service.BaseDTO;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class TFunction extends BaseDTO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String functionid;
/*     */   private Long subsystemId;
/*     */   private String functionname;
/*     */   private String superfunctionid;
/*     */   private String validated;
/*     */   private String functionurl;
/*     */   private String functiontype;
/*     */   private Long functionorder;
/*     */   private String remark;
/*     */   private String creatorid;
/*     */   private String creator;
/*     */   private Date createdate;
/*     */   private String operatorid;
/*     */   private String operator;
/*     */   private Date opdate;
/*     */   private String expinfoa;
/*     */   private String expinfob;
/*     */   private String expinfoc;
/*     */   private String expinfod;
/*     */   private String expinfoe;
/*     */ 
/*     */   public String getFunctionid()
/*     */   {
/*  46 */     return this.functionid;
/*     */   }
/*     */ 
/*     */   public void setFunctionid(String functionid) {
/*  50 */     this.functionid = functionid;
/*     */   }
/*     */ 
/*     */   public String getFunctionname() {
/*  54 */     return this.functionname;
/*     */   }
/*     */ 
/*     */   public void setFunctionname(String functionname) {
/*  58 */     this.functionname = functionname;
/*     */   }
/*     */ 
/*     */   public String getSuperfunctionid() {
/*  62 */     return this.superfunctionid;
/*     */   }
/*     */ 
/*     */   public void setSuperfunctionid(String superfunctionid) {
/*  66 */     this.superfunctionid = superfunctionid;
/*     */   }
/*     */ 
/*     */   public String getValidated() {
/*  70 */     return this.validated;
/*     */   }
/*     */ 
/*     */   public void setValidated(String validated) {
/*  74 */     this.validated = validated;
/*     */   }
/*     */ 
/*     */   public String getFunctionurl() {
/*  78 */     return this.functionurl;
/*     */   }
/*     */ 
/*     */   public void setFunctionurl(String functionurl) {
/*  82 */     this.functionurl = functionurl;
/*     */   }
/*     */ 
/*     */   public String getFunctiontype() {
/*  86 */     return this.functiontype;
/*     */   }
/*     */ 
/*     */   public void setFunctiontype(String functiontype) {
/*  90 */     this.functiontype = functiontype;
/*     */   }
/*     */ 
/*     */   public Long getFunctionorder() {
/*  94 */     return this.functionorder;
/*     */   }
/*     */ 
/*     */   public void setFunctionorder(Long functionorder) {
/*  98 */     this.functionorder = functionorder;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 102 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 106 */     this.remark = remark;
/*     */   }
/*     */ 
/*     */   public String getCreatorid() {
/* 110 */     return this.creatorid;
/*     */   }
/*     */ 
/*     */   public void setCreatorid(String creatorid) {
/* 114 */     this.creatorid = creatorid;
/*     */   }
/*     */ 
/*     */   public String getCreator() {
/* 118 */     return this.creator;
/*     */   }
/*     */ 
/*     */   public void setCreator(String creator) {
/* 122 */     this.creator = creator;
/*     */   }
/*     */ 
/*     */   public Date getCreatedate() {
/* 126 */     return this.createdate;
/*     */   }
/*     */ 
/*     */   public void setCreatedate(Date createdate) {
/* 130 */     this.createdate = createdate;
/*     */   }
/*     */ 
/*     */   public String getOperatorid() {
/* 134 */     return this.operatorid;
/*     */   }
/*     */ 
/*     */   public void setOperatorid(String operatorid) {
/* 138 */     this.operatorid = operatorid;
/*     */   }
/*     */ 
/*     */   public String getOperator() {
/* 142 */     return this.operator;
/*     */   }
/*     */ 
/*     */   public void setOperator(String operator) {
/* 146 */     this.operator = operator;
/*     */   }
/*     */ 
/*     */   public Date getOpdate() {
/* 150 */     return this.opdate;
/*     */   }
/*     */ 
/*     */   public void setOpdate(Date opdate) {
/* 154 */     this.opdate = opdate;
/*     */   }
/*     */ 
/*     */   public String getExpinfoa() {
/* 158 */     return this.expinfoa;
/*     */   }
/*     */ 
/*     */   public void setExpinfoa(String expinfoa) {
/* 162 */     this.expinfoa = expinfoa;
/*     */   }
/*     */ 
/*     */   public String getExpinfob() {
/* 166 */     return this.expinfob;
/*     */   }
/*     */ 
/*     */   public void setExpinfob(String expinfob) {
/* 170 */     this.expinfob = expinfob;
/*     */   }
/*     */ 
/*     */   public String getExpinfoc() {
/* 174 */     return this.expinfoc;
/*     */   }
/*     */ 
/*     */   public void setExpinfoc(String expinfoc) {
/* 178 */     this.expinfoc = expinfoc;
/*     */   }
/*     */ 
/*     */   public String getExpinfod() {
/* 182 */     return this.expinfod;
/*     */   }
/*     */ 
/*     */   public void setExpinfod(String expinfod) {
/* 186 */     this.expinfod = expinfod;
/*     */   }
/*     */ 
/*     */   public String getExpinfoe() {
/* 190 */     return this.expinfoe;
/*     */   }
/*     */ 
/*     */   public void setExpinfoe(String expinfoe) {
/* 194 */     this.expinfoe = expinfoe;
/*     */   }
/*     */ 
/*     */   public Long getSubsystemId() {
/* 198 */     return this.subsystemId;
/*     */   }
/*     */ 
/*     */   public void setSubsystemId(Long subsystemId) {
/* 202 */     this.subsystemId = subsystemId;
/*     */   }
/*     */ }

/* Location:           E:\workspace\navy\src\海军\WebRoot\WEB-INF\lib\HDPriv.jar
 * Qualified Name:     cn.com.hd.dto.priv.TFunction
 * JD-Core Version:    0.6.0
 */