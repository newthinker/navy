/*    */ package cn.com.hd.xmlparser.dto;
/*    */ 
/*    */ public class SystemDTO
/*    */ {
/*    */   private String type;
/*    */   private String url;
/*    */ 
/*    */   public String getType()
/*    */   {
/* 10 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 13 */     this.type = type;
/*    */   }
/*    */   public String getUrl() {
/* 16 */     return this.url;
/*    */   }
/*    */   public void setUrl(String url) {
/* 19 */     this.url = url;
/*    */   }
/*    */ }

/* Location:           E:\workspace\navy\src\海军\WebRoot\WEB-INF\lib\HDCube.jar
 * Qualified Name:     cn.com.hd.xmlparser.dto.SystemDTO
 * JD-Core Version:    0.6.0
 */