/*   */ package cn.com.hd.error;
/*   */ 
/*   */ public class BaseException extends Exception
/*   */ {
/*   */   public BaseException(String exceptionMessage)
/*   */   {
/* 6 */     super(exceptionMessage);
/*   */   }
/*   */ }

/* Location:           E:\workspace\navy\src\海军\WebRoot\WEB-INF\lib\HDCube.jar
 * Qualified Name:     cn.com.hd.error.BaseException
 * JD-Core Version:    0.6.0
 */