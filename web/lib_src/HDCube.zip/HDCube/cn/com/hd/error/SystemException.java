/*   */ package cn.com.hd.error;
/*   */ 
/*   */ public class SystemException extends BaseException
/*   */ {
/*   */   public SystemException(String errorMessage)
/*   */   {
/* 6 */     super(errorMessage);
/*   */   }
/*   */ }

/* Location:           E:\workspace\navy\src\海军\WebRoot\WEB-INF\lib\HDCube.jar
 * Qualified Name:     cn.com.hd.error.SystemException
 * JD-Core Version:    0.6.0
 */