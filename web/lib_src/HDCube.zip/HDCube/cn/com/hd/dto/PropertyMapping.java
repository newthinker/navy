/*    */ package cn.com.hd.dto;
/*    */ 
/*    */ public class PropertyMapping
/*    */ {
/*    */   private String name;
/*    */   private String type;
/*    */   private String columnName;
/*    */   private Integer colunmLength;
/*    */   private String generate;
/*    */   private String generatevalue;
/*    */ 
/*    */   public String getName() {
/* 13 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 16 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 19 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 22 */     this.type = type;
/*    */   }
/*    */   public String getColumnName() {
/* 25 */     return this.columnName;
/*    */   }
/*    */   public void setColumnName(String columnName) {
/* 28 */     this.columnName = columnName;
/*    */   }
/*    */   public Integer getColunmLength() {
/* 31 */     return this.colunmLength;
/*    */   }
/*    */   public void setColunmLength(Integer colunmLength) {
/* 34 */     this.colunmLength = colunmLength;
/*    */   }
/*    */   public String getGenerate() {
/* 37 */     return this.generate;
/*    */   }
/*    */   public void setGenerate(String generate) {
/* 40 */     this.generate = generate;
/*    */   }
/*    */   public String getGeneratevalue() {
/* 43 */     return this.generatevalue;
/*    */   }
/*    */   public void setGeneratevalue(String generatevalue) {
/* 46 */     this.generatevalue = generatevalue;
/*    */   }
/*    */ }

/* Location:           E:\workspace\navy\src\海军\WebRoot\WEB-INF\lib\HDCube.jar
 * Qualified Name:     cn.com.hd.dto.PropertyMapping
 * JD-Core Version:    0.6.0
 */